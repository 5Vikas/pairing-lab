import { PairingLab } from '@/components/pairing-lab'

export default function Page() {
  return (
    <div className="min-h-dvh">
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-10 focus:rounded-md focus:bg-primary focus:px-3 focus:py-2 focus:text-primary-foreground"
      >
        Skip to scenarios
      </a>
      <header className="border-b">
        <div className="mx-auto max-w-3xl px-4 py-10 sm:px-6 sm:py-14">
          <p className="font-mono text-xs font-medium uppercase tracking-wider text-primary">
            QA practice
          </p>
          <h1 className="mt-2 text-3xl font-semibold tracking-tight text-balance sm:text-4xl">
            Pairing Lab
          </h1>
          <p className="mt-3 max-w-prose text-muted-foreground text-pretty">
            Three smart-camera setup scenarios to practice on. Prepare the starting state, follow
            the steps, compare what you see with the expected behavior, then record your result.
          </p>
        </div>
      </header>

      <main id="main" className="mx-auto max-w-3xl px-4 py-8 sm:px-6 sm:py-10">
        <PairingLab />
      </main>

      <footer className="border-t">
        <div className="mx-auto max-w-3xl px-4 py-6 text-sm text-muted-foreground sm:px-6">
          Pairing Lab by Vikas Sharma
        </div>
      </footer>
    </div>
  )
}
