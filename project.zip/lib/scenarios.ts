export type Scenario = {
  id: string
  title: string
  summary: string
  startingState: string[]
  steps: string[]
  expected: string[]
}

export const scenarios: Scenario[] = [
  {
    id: 'normal-pairing',
    title: 'Normal pairing',
    summary: 'Add a new camera to the companion app on a stable home network.',
    startingState: [
      'Camera is factory reset, powered on and in pairing mode (status light blinking).',
      'Companion app is installed on the phone and the tester is signed in.',
      'Bluetooth and location permissions are granted to the app.',
      'Phone is connected to the home Wi-Fi network the camera will join, and the password is known.',
    ],
    steps: [
      'Open the app and tap Add device.',
      'Select the camera model from the list.',
      'Confirm the camera’s pairing light is blinking when the app asks.',
      'Choose the home Wi-Fi network and enter its password.',
      'Wait while the camera joins the network and registers with the account.',
      'Give the camera a name and assign it to a room.',
      'Open live view for the new camera.',
    ],
    expected: [
      'The app shows progress for each setup stage instead of a single unexplained spinner.',
      'The camera’s status light changes from blinking to its connected state.',
      'The camera appears once in the device list, with the chosen name, marked online.',
      'Live view opens and shows a moving picture from the camera.',
    ],
  },
  {
    id: 'wifi-lost-during-setup',
    title: 'Losing Wi-Fi during setup',
    summary: 'Cut the network while the camera is joining it, then recover.',
    startingState: [
      'Same as Normal pairing: camera reset and in pairing mode, tester signed in, permissions granted.',
      'Tester can switch the router or access point off and on during the test.',
    ],
    steps: [
      'Start the Add device flow and continue through Wi-Fi password entry.',
      'While the app shows the camera connecting, switch the router off.',
      'Watch the app and the camera’s status light without tapping anything.',
      'Switch the router back on and wait for the network to return.',
      'Follow the app’s retry or restart prompt to finish setup.',
    ],
    expected: [
      'The app does not wait forever; it shows a clear message that the connection was lost.',
      'The message offers a way to retry or restart setup.',
      'No half-added or duplicate camera is left in the device list.',
      'The camera returns to pairing mode or clearly signals that setup failed.',
      'Retrying after the network is back completes pairing normally.',
    ],
  },
  {
    id: 'reconnect-after-setup',
    title: 'Reconnecting after setup',
    summary: 'Check that a paired camera recovers on its own after a network outage.',
    startingState: [
      'Camera is already paired, shown online in the app and live view works.',
      'Tester can switch the router or access point off and on.',
    ],
    steps: [
      'Open live view for the camera.',
      'Switch the router off.',
      'Watch how the app and the camera status light respond.',
      'Switch the router back on. Do not touch the camera or re-run setup.',
      'Wait for the camera to come back online, then open live view again.',
    ],
    expected: [
      'Live view shows a connection-lost message rather than a frozen picture presented as live.',
      'The camera is marked offline in the device list while the network is down.',
      'After the network returns, the camera reconnects by itself with no re-pairing.',
      'The camera is marked online again and live view works.',
      'The camera keeps its name, room and settings.',
    ],
  },
]
