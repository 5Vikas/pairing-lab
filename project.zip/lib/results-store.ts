'use client'

import { useSyncExternalStore } from 'react'

export type Result = 'pass' | 'fail' | 'untested'
export type Results = Record<string, Result>

const STORAGE_KEY = 'pairing-lab:results'
const EMPTY: Results = {}

const listeners = new Set<() => void>()
let cachedRaw: string | null = null
let cachedValue: Results = EMPTY

function read(): Results {
  let raw: string | null = null
  try {
    raw = window.localStorage.getItem(STORAGE_KEY)
  } catch {
    return cachedValue
  }
  if (raw === cachedRaw) return cachedValue
  cachedRaw = raw
  try {
    const parsed = raw ? JSON.parse(raw) : {}
    cachedValue = parsed && typeof parsed === 'object' ? (parsed as Results) : EMPTY
  } catch {
    cachedValue = EMPTY
  }
  return cachedValue
}

function write(next: Results) {
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next))
  } catch {
    cachedRaw = null
    cachedValue = next
  }
  listeners.forEach((listener) => listener())
}

function subscribe(listener: () => void) {
  listeners.add(listener)
  const onStorage = (event: StorageEvent) => {
    if (event.key === STORAGE_KEY) listener()
  }
  window.addEventListener('storage', onStorage)
  return () => {
    listeners.delete(listener)
    window.removeEventListener('storage', onStorage)
  }
}

export function useResults() {
  const results = useSyncExternalStore(subscribe, read, () => EMPTY)

  const setResult = (id: string, value: Result) => {
    write({ ...read(), [id]: value })
  }

  const clearResults = () => write({})

  return { results, setResult, clearResults }
}
