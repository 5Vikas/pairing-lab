'use client'

import { scenarios } from '@/lib/scenarios'
import { useResults, type Result } from '@/lib/results-store'
import { ScenarioCard } from '@/components/scenario-card'
import { Button } from '@/components/ui/button'
import { CopySummaryButton } from '@/components/copy-summary-button'

const RESULT_LABELS: Record<Result, string> = {
  pass: 'Pass',
  fail: 'Fail',
  untested: 'Untested',
}

function isResult(value: unknown): value is Result {
  return value === 'pass' || value === 'fail' || value === 'untested'
}

export function PairingLab() {
  const { results, setResult, clearResults } = useResults()

  const resultFor = (id: string): Result => {
    const value = results[id]
    return isResult(value) ? value : 'untested'
  }

  const counts = scenarios.reduce(
    (acc, scenario) => {
      acc[resultFor(scenario.id)] += 1
      return acc
    },
    { pass: 0, fail: 0, untested: 0 } as Record<Result, number>,
  )

  const hasRecorded = counts.pass + counts.fail > 0

  const buildSummary = () =>
    [
      'Pairing Lab test summary',
      ...scenarios.map(
        (scenario, index) => `${index + 1}. ${scenario.title}: ${RESULT_LABELS[resultFor(scenario.id)]}`,
      ),
    ].join('\n')

  return (
    <>
      <section aria-labelledby="progress-heading" className="rounded-xl border bg-muted/50 p-5 sm:p-6">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h2 id="progress-heading" className="text-sm font-semibold">
            Your progress
          </h2>
          <div className="flex flex-wrap items-start gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                if (window.confirm('Reset all results to Untested?')) clearResults()
              }}
              disabled={!hasRecorded}
            >
              Reset results
            </Button>
            <CopySummaryButton getSummary={buildSummary} />
          </div>
        </div>
        <dl className="mt-4 grid grid-cols-3 gap-2" aria-live="polite">
          <div className="rounded-md bg-background p-3">
            <dt className="text-xs text-muted-foreground">Pass</dt>
            <dd className="text-2xl font-semibold tabular-nums text-success">{counts.pass}</dd>
          </div>
          <div className="rounded-md bg-background p-3">
            <dt className="text-xs text-muted-foreground">Fail</dt>
            <dd className="text-2xl font-semibold tabular-nums text-destructive">{counts.fail}</dd>
          </div>
          <div className="rounded-md bg-background p-3">
            <dt className="text-xs text-muted-foreground">Untested</dt>
            <dd className="text-2xl font-semibold tabular-nums">{counts.untested}</dd>
          </div>
        </dl>
        <p className="mt-3 text-xs text-muted-foreground">
          Results are saved only in this browser. Nothing is sent anywhere.
        </p>
      </section>

      <nav aria-label="Scenarios" className="mt-8">
        <ol className="flex flex-wrap gap-2 text-sm">
          {scenarios.map((scenario, index) => (
            <li key={scenario.id}>
              <a
                href={`#${scenario.id}`}
                className="inline-flex min-h-9 items-center rounded-full border px-3 hover:border-primary hover:text-primary focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring"
              >
                {index + 1}. {scenario.title}
              </a>
            </li>
          ))}
        </ol>
      </nav>

      <div className="mt-6 flex flex-col gap-6">
        {scenarios.map((scenario, index) => (
          <ScenarioCard
            key={scenario.id}
            scenario={scenario}
            index={index}
            result={resultFor(scenario.id)}
            onResultChange={(value) => setResult(scenario.id, value)}
          />
        ))}
      </div>
    </>
  )
}
