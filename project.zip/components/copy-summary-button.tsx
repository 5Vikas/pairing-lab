'use client'

import { useEffect, useRef, useState } from 'react'
import { Button } from '@/components/ui/button'

type CopyStatus = 'idle' | 'copied' | 'failed'

function copyWithFallback(text: string): boolean {
  const textarea = document.createElement('textarea')
  textarea.value = text
  textarea.setAttribute('readonly', '')
  textarea.style.position = 'fixed'
  textarea.style.opacity = '0'
  document.body.appendChild(textarea)
  textarea.select()
  let ok = false
  try {
    ok = document.execCommand('copy')
  } catch {
    ok = false
  }
  document.body.removeChild(textarea)
  return ok
}

export function CopySummaryButton({ getSummary }: { getSummary: () => string }) {
  const [status, setStatus] = useState<CopyStatus>('idle')
  const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  useEffect(() => {
    return () => {
      if (timeoutRef.current) clearTimeout(timeoutRef.current)
    }
  }, [])

  const handleCopy = async () => {
    const text = getSummary()
    let ok = false
    try {
      await navigator.clipboard.writeText(text)
      ok = true
    } catch {
      ok = copyWithFallback(text)
    }
    setStatus(ok ? 'copied' : 'failed')
    if (timeoutRef.current) clearTimeout(timeoutRef.current)
    timeoutRef.current = setTimeout(() => setStatus('idle'), 4000)
  }

  return (
    <div className="flex flex-col items-end gap-1">
      <Button variant="default" size="sm" onClick={handleCopy}>
        {status === 'copied' ? 'Copied' : 'Copy test summary'}
      </Button>
      <p role="status" aria-live="polite" className="min-h-4 text-xs text-muted-foreground">
        {status === 'copied' && 'Test summary copied to clipboard.'}
        {status === 'failed' && (
          <span className="text-destructive">Copy failed. Your browser blocked clipboard access.</span>
        )}
      </p>
    </div>
  )
}
