'use client'

import type { Scenario } from '@/lib/scenarios'
import type { Result } from '@/lib/results-store'
import { ResultControl } from '@/components/result-control'

function Section({
  heading,
  items,
  ordered = false,
}: {
  heading: string
  items: string[]
  ordered?: boolean
}) {
  const List = ordered ? 'ol' : 'ul'
  return (
    <div>
      <h3 className="mb-2 text-xs font-semibold uppercase tracking-wider text-primary">{heading}</h3>
      <List
        className={
          ordered
            ? 'list-decimal space-y-1.5 pl-5 text-sm leading-relaxed marker:font-medium marker:text-muted-foreground'
            : 'list-disc space-y-1.5 pl-5 text-sm leading-relaxed marker:text-muted-foreground'
        }
      >
        {items.map((item) => (
          <li key={item} className="text-pretty">
            {item}
          </li>
        ))}
      </List>
    </div>
  )
}

export function ScenarioCard({
  scenario,
  index,
  result,
  onResultChange,
}: {
  scenario: Scenario
  index: number
  result: Result
  onResultChange: (value: Result) => void
}) {
  const headingId = `${scenario.id}-heading`
  return (
    <article
      id={scenario.id}
      aria-labelledby={headingId}
      className="scroll-mt-6 rounded-xl border bg-card p-5 text-card-foreground sm:p-6"
    >
      <header className="mb-5">
        <p className="font-mono text-xs text-muted-foreground">Scenario {index + 1}</p>
        <h2 id={headingId} className="mt-1 text-xl font-semibold tracking-tight text-balance">
          {scenario.title}
        </h2>
        <p className="mt-1 text-sm text-muted-foreground text-pretty">{scenario.summary}</p>
      </header>

      <div className="flex flex-col gap-5">
        <Section heading="Starting state" items={scenario.startingState} />
        <Section heading="Steps" items={scenario.steps} ordered />
        <Section heading="Expected practice behavior" items={scenario.expected} />
      </div>

      <div className="mt-6 border-t pt-5">
        <ResultControl
          scenarioId={scenario.id}
          title={scenario.title}
          value={result}
          onChange={onResultChange}
        />
      </div>
    </article>
  )
}
