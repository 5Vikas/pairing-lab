'use client'

import { cn } from '@/lib/utils'
import type { Result } from '@/lib/results-store'

const options: { value: Result; label: string; selected: string }[] = [
  { value: 'pass', label: 'Pass', selected: 'border-success bg-success text-success-foreground' },
  { value: 'fail', label: 'Fail', selected: 'border-destructive bg-destructive text-destructive-foreground' },
  { value: 'untested', label: 'Untested', selected: 'border-foreground bg-foreground text-background' },
]

export function ResultControl({
  scenarioId,
  title,
  value,
  onChange,
}: {
  scenarioId: string
  title: string
  value: Result
  onChange: (value: Result) => void
}) {
  return (
    <fieldset>
      <legend className="mb-2 text-sm font-medium">
        Your result<span className="sr-only"> for {title}</span>
      </legend>
      <div className="grid grid-cols-3 gap-2">
        {options.map((option) => {
          const checked = value === option.value
          return (
            <label
              key={option.value}
              className={cn(
                'flex min-h-11 cursor-pointer items-center justify-center rounded-md border px-3 text-sm font-medium transition-colors',
                'has-[:focus-visible]:ring-2 has-[:focus-visible]:ring-ring has-[:focus-visible]:ring-offset-2 has-[:focus-visible]:ring-offset-background',
                checked ? option.selected : 'border-border bg-background hover:bg-muted',
              )}
            >
              <input
                type="radio"
                name={`result-${scenarioId}`}
                value={option.value}
                checked={checked}
                onChange={() => onChange(option.value)}
                className="sr-only"
              />
              {option.label}
            </label>
          )
        })}
      </div>
    </fieldset>
  )
}
